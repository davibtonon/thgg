#tcc 

 - [ ] Amor, N. B; Benferhat, S; Elouedi, Z. 2004. Naive Bayes vs Decision Trees in Intrusion Detection Systems. ACM Symposium on Applied Computing
 - [ ] Canadian Institute for Cybersecurity.[CIC]. 2018. A collaborative project between the Communications Security Establishment (CSE) & the Canadian Institute for Cybersecurity (CIC). Disponível em:< https://www.unb.ca/cic/datasets/ids-2018.html>. Acesso em 14 de out. 2023.
 - [ ] Fortinet. 2022. Brasil sofreu mais de 88,5 bilhões de tentativas de ataques cibernéticos em 2021.
 - [ ] Kaggle.2022. CIC-IDS-Collection. Disponível em: <https://www.kaggle.com/datasets/dhoogla/cicidscollection> Acesso em: 14 de out. 2023.
 - [ ] McKinsey & Company [McKinsey].2022 Cybersecurity trends: Looking over the Horizon. Dispnível em: < https://www.mckinsey.com/capabilities/risk-and-resilience/our-insights/cybersecurity/cybersecurity-trends-looking-over-the-horizon >. Acesso em:02 de mar. 2024.
 - [ ] Neto, H. S.; Lacerda, W.S.; 2019. Sistema de Detecção de Intrusão em Redes de Computadores Utilizando Máquinas de Vetores de Suporte. In: Simpósio Brasileiro de Automação Inteligente,2019, Ouro Preto, MG, Brasil. Anais... p. 366 – 388.
 - [ ] Okada, H.K.R.; Neves, A.R.N.; Shitsuka, R.; 2019. Análise de Algoritmos de Indução de Árvores de Decisão
 - [ ] Pedregosa, F.; Varoquaux, G.; Gramfort, A.; Michel, V.; Thirion, B.; Grisel, O.; Blondel, M.; Prettenhofer, P.; Weiss, R.; Dubourg, V.; Vanderplas, J.; Passos, A.; Cournapeau, D.; Brucher, M.; Perrot, M.; Duchesnay, É. 2011. Scikit-learn: Machine Learning in Python
 - [ ] Tanenbaum,A.S.; Wetherall,D.J. 2011. Redes de computadores. 5ed.Pearson, São Paulo, SP, Brasil.
 - [ ] Thakkar, A.; Lohiya, R. 2020. A Review of the Advancement in Intrusion Detection Datasets. Procedia Computer Scinece, 167: 636 – 645
 - [ ] D’hooge, L.; Verkerken, M.; Volckaert, B.; Wauters, T.; Turck, F. 2022. Establishing the Contaminating Effect of Metadata Feature Inclusion in Machine-Learned Network Intrusion Detection Models