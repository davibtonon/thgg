#tcc
1. O que são IDS ?
2. O que são Arvores de Decisão ?
3. O que é Naives Bayes ?
4. Qual a diferença entres eles ?
5. Interpretação matriz de confusão ?
6. O que é Precisão ?
	- Proporção de instâncias classificadas como positivas que são positivas. No meu caso devo pegar o a célula da classe que estou analisando e dividir pelo total da coluna. Ela vai me dizer ser o modelo e bom e classificar os valores positivos.
	- No caso das classes web e infiltration os valores são baixos pois são classificados 625 e 982 instâncias erroneamente.
1. O que é sensibilidade ?
2. O que é F1-Scores ?


