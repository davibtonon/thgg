
- Agosto: [[#Noites Brancas - Fiódor Dostoiévski]]
- Setembro: Memórias Póstumas de Braz Cubas - Machado de Assis.
- Outubro: Frankenstein - Mary Shelley.
- Novembro: 
- Dezembro:


##### Noites Brancas - Fiódor Dostoiévski
- [x] Compra livros
- [ ] Reunião 1 - Capítulo 2º - 15/08/24
- [ ] Reunião final - Capítulo 3º - 31/08/24