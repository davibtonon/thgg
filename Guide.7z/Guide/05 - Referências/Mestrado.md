
UNESP
- Duas cartas de recomendação. Isso é problema. Como obter ?
- [Programa](https://www.ibilce.unesp.br/#!/pos-graduacao/programas-de-pos-graduacao/ciencia-da-computacao/)
- Fazer Mestrado Computação Aplicada - Sistemas de Computação
-  Quero fazer com Adriano Mauro Cansian (M/D) - Gostei do trabalho dele, é coordenador do laboratório [ACME](https://acmesecurity.org/). Preciso fazer algo para chama a atenção dele.
