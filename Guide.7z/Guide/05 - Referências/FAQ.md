
- Conte um pouco sobre sua trajetória acadêmica. Esta pergunta é obrigatória:
	-  Tenho formação em Engenharia Mecânica, porém vi maiores oportunidades de crescimento na área de tecnologia. Por isso, no ano passado, iniciei uma segunda graduação em Análise e Desenvolvimento de Sistemas. Hoje, estou em buscar de estágio para ganhar experiência prática no mercado.
	
- Já participou de projetos práticos? (Pessoais ou acadêmicos) ? Descreva-os:
	- Sim, durante meu MBA em Data Science e Analytics, utilizei uma base de dados pública para a classificação de ataques cibernéticos na entrega do meu TCC. Na análise, empreguei a biblioteca Pandas para o tratamento e a exploração inicial dos dados. Em seguida, utilizei o framework scikit-learn para a implementação de modelos de árvores de decisão e Naïve Bayes. Além disso, tive a oportunidade de participar do Alura Challenges, onde desenvolvi uma API REST utilizando o Django Rest Framework.
	
- Qual sua principal motivação para atuar na área de Desenvolvimento ?
	- Minha principal motivação para atuar na área de Desenvolvimento é a oportunidade de transformar ideias em soluções funcionais e impactantes. Gosto do desafio de resolver problemas complexos por meio da programação, além de estar sempre aprendendo e evoluindo com novas tecnologias.



Tenho formação em Engenharia Mecânica, porém vi maiores oportunidades de crescimento na área de tecnologia. Por isso, no ano passado, iniciei uma segunda graduação em Análise e Desenvolvimento de Sistemas. Hoje, estou em buscar de estágio para ganhar experiência prática no mercado. 


Profissional com experiência em coleta, organização e intepretação de dados, utilizando ferramentas como power BI, sql e python para criação de dashaborad e relatorios. 

Profissional com experiência em coleta, organização e interpretação de dados, especializado na criação de dashboards e relatórios interativos utilizando ferramentas como Power BI, SQL e Python. Focado em transformar dados brutos em insights valiosos para apoiar a tomada de decisões estratégicas.



Fale sobre você e sua trajetória profissional, contando como pode ajudar a empresa no desafio descrito na vaga.

Sou formado em Engenharia Mecânica e, ao longo da minha trajetória, desenvolvi uma sólida experiência em planejamento, análise de dados e desenvolvimento de soluções para monitoramento de indicadores.

Atualmente, utilizo Power BI, SQL e Python para coletar, organizar e transformar  dados em relatórios interativos e dashboards que apoiam a tomada de decisões. Na Seatrium, por exemplo, desenvolvi relatórios de BI para acompanhar métricas de desempenho, trabalhei em conjunto com a equipe de planejamento para definir escopos claros e realizei análises detalhadas para a alocação eficiente de recursos.

Meu diferencial está em combinar a visão analítica com a experiência prática adquirida em setores como construção naval e papel e celulose. Com isso, posso ajudar a empresa a transformar dados em decisões estratégicas, automatizar processos, melhorar a eficiência operacional e entregar soluções personalizadas para os desafios apresentados na vaga.

Estou sempre em busca de aprimoramento e vejo essa oportunidade como uma chance de aplicar minhas habilidades técnicas, colaborar com a equipe e contribuir para o crescimento e inovação da empresa.

Sou formado em Engenharia Mecânica, porém vi maiores oportunidades de crescimento na área de tecnologia. Por isso, no ano passado, iniciei uma segunda graduação em Análise e Desenvolvimento de Sistemas. Além disso tem um MBA em Data Science e Analytcs, foi a parti dele que desisti ir para área de dados.

