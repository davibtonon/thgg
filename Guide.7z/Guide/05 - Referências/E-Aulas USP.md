

[Álgebra Linear I](https://eaulas.usp.br/portal/course.action?course=10182)
[Álgebra Linear II](https://eaulas.usp.br/portal/course.action?course=10785)

[Computação Bioinspirada](https://eaulas.usp.br/portal/course.action?course=9291)
[Arquitetura de Computadores](https://eaulas.usp.br/portal/course.action?course=16574)
[Reconhecimento de Padrões](https://eaulas.usp.br/portal/course.action?course=9596)
[# Big Data](https://eaulas.usp.br/portal/course.action?course=34136)
[# Governança de TIs](https://eaulas.usp.br/portal/course.action?course=34717)
[# Governança e Gestão de TI para Cibersegurança](https://eaulas.usp.br/portal/course.action?course=37130)
[# Banco de Dados I](https://eaulas.usp.br/portal/course.action?course=23561)
[# Segurança da Informação: Algoritmos e Protocolos](https://eaulas.usp.br/portal/course.action?course=18210)
[# Segurança da Informação](https://eaulas.usp.br/portal/course.action?course=9927)
[# História da América Independente I](https://eaulas.usp.br/portal/course.action?course=5044)
[# História da América Independente II](https://eaulas.usp.br/portal/course.action?course=6651)

