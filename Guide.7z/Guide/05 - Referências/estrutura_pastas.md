
# Estrutura de Pastas Pessoal - Organização Digital

## 📁 /Leituras
Armazena **arquivos brutos** de leitura:
- Livros (PDF, EPUB, MOBI)
- Artigos
- Papers acadêmicos
- Whitepapers

**Exemplo:**
```
/Leituras
    ├── Programação
    │     ├── Clean Code.pdf
    │     └── Design Patterns.pdf
    ├── Ciência de Dados
    │     └── Hands-On Machine Learning.pdf
    └── Literatura
          └── Dom Casmurro.epub
```

## 📁 /Cursos
Armazena **materiais de cursos** que está realizando:
- Slides
- PDFs
- Certificados
- Exercícios

**Exemplo:**
```
/Cursos
    ├── Data Science - Alura
    ├── Python - Udemy
    └── AWS Cloud Practitioner
```

## 📁 /Obsidian
Pasta com seus **Vaults de notas e anotações**:
- Anotações de leitura
- Fichamentos
- Mapas mentais
- Resumos de cursos

**Exemplo:**
```
/Obsidian
    ├── Pessoal
    ├── Estudos
    └── Projetos
```

## 📁 /Projetos
Pasta central onde ficam **todos os seus projetos**, sejam pessoais, acadêmicos ou profissionais.

```
/Projetos
    ├── Desenvolvimento
    │     ├── [Projeto de Programação 1]
    │     └── [Projeto de Software 2]
    │
    ├── Estudo
    │     ├── [Resumo de Livro]
    │     ├── [Análise de Artigo]
    │     └── [Exercícios de Curso]
    │
    ├── Pesquisa
    │     ├── [Iniciação Científica]
    │     └── [Trabalho de Conclusão de Curso]
    │
    ├── Escrita
    │     ├── [Blog Pessoal]
    │     ├── [Artigo para publicação]
    │     └── [Livro que está escrevendo]
    │
    ├── Criativos
    │     ├── [Edição de Vídeo]
    │     ├── [Design Gráfico]
    │     └── [Projeto de Música]
    │
    └── Outros
          ├── [Organização Pessoal]
          └── [Outros Projetos]
```

## 📁 /Programas
Armazena **instaladores e softwares**:
- Instaladores EXE/MSI/DEB
- Softwares portáteis
- Drivers

**Exemplo:**
```
/Programas
    ├── Instaladores
    ├── Portáteis
    └── ISOs
          ├── Windows.iso
          ├── Ubuntu.iso
          └── Office.iso
```

## 📁 /Imagens ISO
Se tiver **muitas imagens ISO**, pode ter uma pasta separada:

```
/Imagens ISO
    ├── Sistemas Operacionais
    │     ├── Ubuntu 24.04.iso
    │     ├── Windows 11.iso
    │     └── Fedora.iso
    └── Softwares
          ├── Office.iso
          └── AutoCAD.iso
```

## 📁 /Mídias
Armazena entretenimento e arquivos diversos:

```
/Mídias
    ├── Filmes
    ├── Séries
    ├── Animes
    ├── Torrents
    └── Música
```

## ✅ Fluxo recomendado

| Tipo de arquivo | Pasta recomendada |
|-----------------|-------------------|
| PDF, EPUB | `/Leituras` |
| Anotações | `/Obsidian` |
| Desenvolvimento | `/Projetos/Desenvolvimento` |
| Artigo ou blog | `/Projetos/Escrita` |
| Instalações | `/Programas` |
| Sistemas ISO | `/Imagens ISO` |
| Entretenimento | `/Mídias` |

**Dica:**  
- Use nomes **claros** e **sem espaços**, de preferência com **padrões** (`-` ou `_`).  
- Sempre mantenha backups!  

**Atualizado por:** [Seu nome ou assinatura]  
**Data:** [Coloque a data que salvar]  

  

# Estrutura de Pastas - Raiz

  

## 📁 /Raiz

Pasta principal que contém toda a sua organização digital.

  

```

/Raiaz

    ├── Leituras

    │     ├── Programação

    │     ├── Ciência de Dados

    │     └── Literatura

    │

    ├── Cursos

    │     ├── Data Science - Alura

    │     ├── Python - Udemy

    │     └── AWS Cloud Practitioner

    │

    ├── Obsidian

    │     ├── Pessoal

    │     ├── Estudos

    │     └── Projetos

    │

    ├── Projetos

    │     ├── Desenvolvimento

    │     ├── Estudo

    │     ├── Pesquisa

    │     ├── Escrita

    │     ├── Criativos

    │     └── Outros

    │

    ├── Programas

    │     ├── Instaladores

    │     ├── Portáteis

    │     └── ISOs

    │

    ├── Imagens ISO

    │     ├── Sistemas Operacionais

    │     └── Softwares

    │

    └── Mídias

          ├── Filmes

          ├── Séries

          ├── Animes

          ├── Torrents

          └── Música

```

  

**Dica:**  

- Estrutura modular, facilita encontrar e armazenar arquivos rapidamente.  

- Nomes claros, padronizados e com backups regulares.

  

**Atualizado por:** [Seu nome ou assinatura]  

**Data:** [Coloque a data que salvar]