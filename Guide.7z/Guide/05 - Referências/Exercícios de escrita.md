Alguns links e informações a respeito do curso da [Domestika](https://www.domestika.org/pt/courses/3414-exercicios-de-escrita-da-folha-em-branco-a-pratica-cotidiana/units/12863-introducao)
## Introdução

#### Palestras Recomendas

[Lynda Barry](https://www.youtube.com/watch?v=hmT4wLWksOw)
[Anne Lamott](https://www.youtube.com/watch?v=X41iulkRqZU)
[Júlio Cortázar](https://www.rtve.es/play/videos/a-fondo/julio-cortazar/1051583/)
[Atrás da Cortina](https://www.youtube.com/@BehindtheCurtain/videos)


Livro - [642 coisas para escrever](https://www.chroniclebooks.com/products/642-things-to-write-about)
Site - https://www.escribir.me/

