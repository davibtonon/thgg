
Pretendo ir para Bebedouro - SP, por isto devo começa a procura emprego agora.

## Lista de cidades

- [[#Ribeirão Preto]]
- São José do Rio Preto
- Sertãozinho
- Barretos
- Araraquara
- Jaboticabal

1. Qual distância destas cidades ?
2.  Quais empresas estão localizadas nelas ?
3. Quais delas tem universidades ?

---

### Ribeirão Preto
#mestrado 
Pelo que estou lendo no Wikipédia essa me parece ser a melhor opção, inclusive tem um polo da USP- Ribeirão preto com uma pós que tenho interesse [Pós-Graduação em Computação Aplicada](https://sites.google.com/usp.br/ppgca/sobre).

Eles são forte no setor de serviço sendo a principal fonte econômica, isto é bom foge um pouco do que estou acostumado aqui na minha região. Eles tem [Parque Tecnológico de Ribeirão Preto](https://pt.wikipedia.org/wiki/Parque_Tecnol%C3%B3gico_de_Ribeir%C3%A3o_Preto) uma ótima opção.




