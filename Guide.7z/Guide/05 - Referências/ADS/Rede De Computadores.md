
## Questão 1

Olá, estudante! Realize a seguinte leitura e responda ao que é solicitado:  


Imagine que você faz parte de uma equipe de desenvolvimento de um novo sistema de compartilhamento de arquivos para uma _startup_ inovadora. O objetivo é criar uma plataforma descentralizada, altamente escalável e resistente a falhas. Seu chefe acaba de lhe passar uma missão: estudar os principais conceitos de Redes _Peer-to-Peer_ (P2P) e Tabelas de Hash Distribuídas (DHTs) para propor a melhor abordagem para o sistema.  
  
Você já parou para pensar em como funcionam aplicações como o BitTorrent, a rede Tor ou, até mesmo, sistemas de _blockchain_? Todas essas tecnologias utilizam conceitos de redes P2P e mecanismos distribuídos para garantir eficiência, segurança e escalabilidade. Agora, é a sua vez de explorar esse universo e propor soluções para o projeto da startup!  
  
Para desenvolver sua solução, você precisará estudar os seguintes tópicos e responder às perguntas a seguir com base no livro **Redes de Computadores** dos autores **Behrouz A. Forouzan e Firouz Mosharraf** (páginas 93 a 115), como se estivesse explicando para um colega de equipe.  
  
**1. Redes _Peer-to-Peer_ (P2P)**  

O que são redes P2P e como elas diferem de arquiteturas cliente-servidor?  

São rede de computadores na qual um peer(usuário) poder compartilhar um arquivos com outros peer, sem a necessidade de um servido central.  A medida que novos peer se juntam a rede, mais copias dos arquivos ficam disponíveis 

São redes de computadores nas quais um _peer_ (usuário) pode compartilhar arquivos com outros _peers_, sem a necessidade de um servidor central. À medida que novos _peers_ se juntam à rede, mais cópias dos arquivos ficam disponíveis.

Quais são os principais desafios e benefícios desse tipo de rede?  
  O principal desafio é descobrir quais peers tem o arquivo desejado, e qual o peer mais próximo. Como não há necessidade de um servidor central a rede ser torna distribuída.

O principal desafio é descobrir quais _peers_ possuem o arquivo desejado e qual deles está mais próximo. Como não há necessidade de um servidor central, a rede se torna distribuída.

**2. Tabelas de Hash Distribuídas (DHTs)**  
O que é uma DHT e qual é o seu papel em redes descentralizadas?  
É uma tabela de referências de dados, ela permite saber qual peer está com qual arquivo.

É uma tabela de referência de dados que permite identificar qual _peer_ está com qual arquivo.

Como as DHTs armazenam Objeto?  

Elas usam algoristmos com SHA, para transforma o objeto(arquivo) e o IP da seed e
Eles armazenam objeto em formato de hash, utilizando o algoritimos com SHA. No qual o nome do objeto(arquivo) e o IP do usuário são transformado em um hash.

Elas utilizam algoritmos como o SHA para transformar o nome do objeto (arquivo) e o IP do usuário em um _hash_. Dessa forma, os objetos são armazenados no formato de _hash_, o que facilita sua localização dentro da rede.
  
Obs.: o livro Redes de Computadores dos autores **Behrouz A. Forouzan e Firouz Mosharraf** está disponível na "Minha Biblioteca" em seu Studeo.



### **1. Redes P2P**

**O que são redes P2P e como elas diferem de arquiteturas cliente-servidor?**  
São redes de computadores nas quais um _peer_ (usuário) pode compartilhar arquivos com outros _peers_, sem a necessidade de um servidor central. À medida que novos _peers_ se juntam à rede, mais cópias dos arquivos ficam disponíveis.

**Quais são os principais desafios e benefícios desse tipo de rede?**  
O principal desafio é descobrir quais _peers_ possuem o arquivo desejado e qual deles está mais próximo. Como não há necessidade de um servidor central, a rede se torna distribuída.

---

### **2. Tabelas de Hash Distribuídas (DHTs)**

**O que é uma DHT e qual é o seu papel em redes descentralizadas?**  
É uma tabela de referência de dados que permite identificar qual _peer_ está com qual arquivo.

**Como as DHTs armazenam objetos?**  
Elas utilizam algoritmos como o SHA para transformar o nome do objeto (arquivo) e o IP do usuário em um _hash_. Dessa forma, os objetos são armazenados no formato de _hash_, o que facilita sua localização dentro da rede.

---

Se quiser, posso também te ajudar a melhorar o estilo do texto, deixando-o mais fluido e técnico, dependendo do seu objetivo (ex: trabalho acadêmico, apresentação etc.). Deseja?
## Mapa

Olá, estudante! Agora é hora de aplicar os conceitos aprendidos na disciplina em um cenário prático. Vamos lá?  
  
**Fase 1: Cenário**  
  
A Tecnologia da Informação (TI) é um pilar essencial no desenvolvimento de projetos de software, impactando diretamente na eficiência, segurança e escalabilidade das soluções empresariais. De acordo com Tanenbaum e Wetherall (2011), a infraestrutura de redes de computadores desempenha um papel crucial na conectividade entre sistemas, influenciando a comunicação e o compartilhamento de dados em ambientes corporativos.  Além disso, Laudon e Laudon (2020) ressaltam que a TI não apenas possibilita a automação e otimização dos processos organizacionais, mas também é um fator determinante para a inovação e competitividade das empresas no cenário global.  
  
Fonte: LAUDON, K. C.; LAUDON, J. P. **Sistemas de informação gerenciais**. 15. ed. São Paulo: Pearson, 2020.  
TANENBAUM, A. S.; WETHERALL, D. J. **Redes de computadores**. 5. ed. São Paulo: Pearson, 2011.  
  
Nesse contexto, imagine que você foi contratado como especialista em redes para projetar e implementar a infraestrutura de TI de uma empresa. Sua missão será configurar uma rede segura e eficiente, garantindo a comunicação entre diferentes setores e dispositivos essenciais para as operações empresariais.  
  
**Fase 2: Infraestrutura Básica**  
  
Você analisará a infraestrutura descrita a seguir. Conforme relatado pelos diretores da empresa, a empresa possui as seguintes redes conectadas ao mesmo servidor central:

**Rede 1: Componentes e necessidades**:

- Duas redes independentes e gerenciáveis para distribuição do tráfego.  
- Um ponto de acesso Wi-Fi dedicado.  
- Seis desktops conectados via cabo.  
- Três tablets corporativos conectados por IP dinâmico.  
- Um servidor de arquivos.  
- A comunicação entre a Rede 1 e o servidor deverá ser protegida.

**Rede 2: Componentes e necessidades:**

Quatro workstations conectadas à rede que liga ao servidor.  
Um dos computadores será o do gerente de TI, que terá um scanner de documentos ligado diretamente.  
Dois terminais de autoatendimento para uso dos funcionários ligados ao servidor.

**Servidor Central: Configuração**

O servidor deverá fornecer IPs dinâmicos aos dispositivos conectados à rede, além de ser um servidor resolvedor de domínios.  
Para acesso à internet, o servidor deverá prover um acesso seguro a determinados protocolos, assim como restringir o acesso a determinados projetos web.  
  
**Fase 3: Endereçamento IP**  
  
Devemos lembrar que um computador não será útil se não tiver um IP atribuído; assim, você deverá configurar todos os computadores. Como temos duas redes, cada uma seguirá um endereço diferente baseado em seu RA, vejamos um exemplo:  
  
RA 2525751-5  
  
Rede 01 a base é o último dígito de seu RA antes do traço: 192.168.1.X    
Rede 02 a base é o penúltimo dígito de seu RA antes do traço: 192.168.5.X    
  
Caso Especiais  
RA 2525703-5 Em caso de dígito zero colocar 1 no lugar: RA 2525713-5  
RA 2525733-5 Em caso de dígito iguais somar +1 no penúltimo dígito: RA 2525743-5  
RA 2525701-5 Em caso de dígito zero e iguais colocar 1 no lugar do zero e adicionar +1 ao outro valor: RA 2525712-5  
RA 2525710-5 Em caso de dígito zero e iguais colocar 1 no lugar do zero e adicionar +1 ao outro valor: RA 2525721-5  
  
OBS.: cada equipamento deverá ter um IP atribuído (Impressoras, repetidores, roteadores Wi-Fi). No caso de equipamentos com IPs Dinâmicos, não é necessário informar o IP.  
  
**Fase 4: Execução**  
  
Sua missão é apresentar uma proposta aos diretores da empresa, que respondam e orientem sobre os questionamentos apresentados a seguir.  
  
1 - Indicação da ferramenta de segurança: Firewall ou Proxy? Justifique a escolha.  
2 - Identificação da topologia utilizada: com base nas informações da infraestrutura, determine e justifique a topologia usada em cada rede.  
3 - Descrição da equipe em cada setor: quantidade de equipamentos em cada sala e sua capacidade de profissionais a serem alocados.  
4 - Configuração de IPs: apresente a tabela com os endereços definidos para cada dispositivo.  
  
**O que você entregará?**  
Você deverá apresentar as respostas para todos os questionamentos apresentados na Fase 4, respondendo ao que foi pedido. Atente-se para a clareza de sua resposta, deve atender exatamente e por completo ao que está sendo solicitado no comando.

