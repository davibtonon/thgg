##### **Microeletrônica e Processamento de Sinais:**

A linha visa a formação de recursos humanos de qualidade, seja para a academia ou setor industrial, na área de projeto de circuitos e sistemas integrados envolvendo soluções em hardware e software, bem como a pesquisa de técnicas avançadas para processamento de sinais em sistemas de comunicação. A linha é sustentada pelos grupos: GMicro – Grupo de Microeletrônica; e GPSCom – Grupo de Pesquisa em Processamento de Sinais e Comunicações.

Professores:

[Mateus Beck Rutzig](https://ufsmpublica.ufsm.br/docente/16069)  
[Raul Ceretta Nunes](https://ufsmpublica.ufsm.br/docente/5253)


[Grupo de Microeletrônica (GMICRO)](https://www.ufsm.br/grupos/gmicro)
[Grupo de Pesquisa em Processamento de Sinais e Comunicações (GPSCOM)](https://www.ufsm.br/grupos/gpscom)

##### **Sistemas Paralelos e Distribuídos:**

A linha visa explorar os limites tecnológicos das redes de computadores e dos sistemas paralelos e distribuídos. Pesquisas envolvem aspectos de redes sem ﬁos e gerência de redes, grades e aglomerados, virtualização e sistemas pervasivos e ubíquos. A linha é alicerçada pelos grupos: GMob – Sistema de Computação Móvel e Pervasiva; LSC – Laboratório de Sistemas de Computação; e GTSeg – Gestão e Tecnologia em Segurança da Informação.

Professores:

[Carlos Raniery Paula dos Santos](https://ufsmpublica.ufsm.br/docente/17459)  
[Celio Trois](https://ufsmpublica.ufsm.br/docente/14683)  
[João Carlos Damasceno Lima](https://ufsmpublica.ufsm.br/docente/5168)  
[João Vicente Ferreira Lima](https://ufsmpublica.ufsm.br/docente/17296)  
[Raul Ceretta Nunes](https://ufsmpublica.ufsm.br/docente/5253)

[Grupo de Pesquisa em Gestão e Tecnologia em Segurança da Informação (GTSEG)](https://www.ufsm.br/grupos/gtseg)




