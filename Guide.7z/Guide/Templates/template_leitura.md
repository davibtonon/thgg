---
Título: <%* let titulo = await tp.system.prompt("Título do Livro") %>
Autor: <%* let autor = await tp.system.prompt("Autor") %>
Gênero: <%* let genero = await tp.system.prompt("Gênero") %>
Categoria: <%* let categoria = await tp.system.suggester(["Acadêmico", "Profissional", "Pessoal"], ["Acadêmico", "Profissional", "Pessoal"]) %>
Data de Início: <% tp.date.now("YYYY-MM-DD") %>
Data de Término: 
Número de Páginas: <%* let paginas = await tp.system.prompt("Número de Páginas") %>
Status: 📖 Em andamento
---

# 📚 <%* titulo %>

## 📌 Informações Gerais
- **Autor:** <%* autor %>  
- **Gênero:** <%* genero %>  
- **Categoria:** <%* categoria %>  
- **Data de Início:** <% tp.date.now("YYYY-MM-DD") %>  
- **Data de Término:**  
- **Número de Páginas:** <%* paginas %>  
- **Objetivo da Leitura:** <%* let objetivo = await tp.system.prompt("Objetivo da Leitura") %>

---

## 📊 Progresso de Leitura
- ✅ **Meta de Leitura:** <%* let meta = await tp.system.prompt("Meta (ex.: 20 páginas/semana)") %>
- 📅 **Checkpoints:**
    - [ ] 25%  
    - [ ] 50%  
    - [ ] 75%  
    - [ ] 100%  

---

## 📝 Notas por Capítulo
### 📖 Capítulo 1:  
-  

### 📖 Capítulo 2:  
-  

---

## 💡 Principais Ideias ou Conceitos
-  
-  

---

## 🔍 Dúvidas e Pontos para Pesquisar
-  

---

## ⭐ Avaliação Final
- **Nota (1 a 5):**  
- **Reflexões Finais:**  
- **Recomendo? Por quê?:**

---

## 📂 Tags
#Leitura #<%* genero %> #<%* autor %> #EmAndamento
