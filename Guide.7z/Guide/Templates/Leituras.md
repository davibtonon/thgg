
---
Título: <% tp.file.title %>
Autor: <% tp.system.prompt("Autor") %>
Gênero: <% tp.system.prompt("Gênero") %>
Categoria: <% tp.system.suggester(["Acadêmico", "Profissional", "Pessoal"], ["Acadêmico", "Profissional", "Pessoal"]) %>
Data de Início: <% tp.date.now("YYYY-MM-DD") %>
Data de Término: 
Número de Páginas: <% tp.system.prompt("Número de Páginas") %>
Status: 📖 Em andamento

creation date: <% tp.file.creation_date() %>
modification date: <% tp.file.last_modified_date("dddd Do MMMM YYYY HH:mm:ss") %>

---

# 📚 <% tp.file.title %>

## 📊 Progresso de Leitura
- ✅ **Meta de Leitura:** <% tp.system.prompt("Meta (ex.: 20 páginas/semana)") %>
- 📅 **Checkpoints:**
    - [ ] 25%  
    - [ ] 50%  
    - [ ] 75%  
    - [ ] 100%  

---

## 📝 Notas por Capítulo
### 📖 Capítulo 1:  
-  

### 📖 Capítulo 2:  
-  

---

## 💡 Principais Ideias ou Conceitos
-  
-  

---

## 🔍 Dúvidas e Pontos para Pesquisar
-  

---

## ⭐ Avaliação Final
- **Nota (1 a 5):**  
- **Reflexões Finais:**  
- **Recomendo? Por quê?:**

---

## 📂 Tags
#Leitura #<% tp.system.prompt("Gênero") %> #<% tp.system.prompt("Autor") %> #EmAndamento
