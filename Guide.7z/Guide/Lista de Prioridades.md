
Nº Pilar Estado Atual Estado Desejado

1. ESPIRITUALIDADE 7
	1. Sempre estive bem eu acho. 
2. CONTRIBUIÇÃO COM O MUNDO4
	1. Não sou o cara mais contribuído
3. PLENITUDE 7
	1. Sempre estive em paz comigo
4. LAZER 5
	1. Sem grana estou optando por lazer mais 'light'
5. SOCIAL 2
	1. Área a ser desenvolvida. 
6. AMOR / RELACIONAMENTO
	1. prefiro não comentar
7. FAMILIA
	1. mais 
8. FINANÇAS
9. PROPÓSITO
10. EQUILÍBRIO EMOCIONAL
11. DESENVOLVIMENTO INTELECTUAL
12. SAÚDE

