 Como muita vezes tenho dificuldade de organizar minha vida, preciso de tudo é um só lugar. Então decidir que tenho que definir regras de como me organizar no físico e digital.



- [[05 - Referências]] - Arquivo onde esta salvo  que preciso par consulta futura.
- Backup de arquivos - Usar somente Google Drive e Mega, sempre com uma copiar local por segurança. Como tenho minhas duvidas sobre Mega, manter arquivos irrelevantes. 
- Sincronização com smarthphone  - Usar programa [Syncthing](https://syncthing.net/). Aqui vou configura uma pasta para artigos e livros digitais. Também para alguns curso que estou fazendo.
- Organização física através do Bullet Jounal , GTD ?
- Criação de partição com criptografia para salva arquivos sensíveis. Veracrypt
- Para cada novo projeto cria nome nº_ano, modelo básico [[00_2025 |Modelo]] usar método *SMART*.



Como organizar minhas ações diárias para manter foco e disciplina ?
Preciso de algo para organizar meus curso, videos, etc. Não tenho certeza do que fazer, mas o importante e ter algo que garanta que eu assista tudo até o final.







