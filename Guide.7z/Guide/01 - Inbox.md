
 - Shiva

- [x] https://jetecommerce.com.br/vemprajet/
https://www.dartdigital.com.br/
https://nst.com.br/#contato
https://spcm.com.br/banco-de-talentos/
- [ ] https://oreons.com/carreiras/
https://itpower.com.br/
https://phelcom.com/pt-br/empresa/
https://www.ccmtecnologia.com.br/careers

## Artigo para lê

https://www.pewresearch.org/internet/2019/04/24/sizing-up-twitter-users/?utm_source=the_news&utm_medium=newsletter&utm_campaign=06-03-2025&_bhlid=8b48a2ae191535fadc009890c0ed6dad2d304e2c#:~:text=regularity,users

https://www.techrepublic.com/article/apple-legal-action-uk-backdoor/?utm_source=the_news&utm_medium=newsletter&utm_campaign=06-03-2025&_bhlid=45b61c0eedf3cc78d4ab69f135ba459ca4d66943


Vagas de emprego
https://unither.csod.com/ux/ats/careersite/1/requisition/945/application?c=unither&lang=pt-BR&jobboardid=0#1

https://vaga2276.criativahumana.com.br/vaga/2276/banco-de-talentos



	https://compassuol.udemy.com/course/simulado-aws-cloud-practitioner-clf-c02-versao-portugues/learn/quiz/6408550#overview


https://compassuol.udemy.com/course/aws-practitioner-em-portugues/learn/quiz/5283884#overview

[SIMULADO CLF-C01](https://simuladoclf.s3.amazonaws.com/portugues.html) 