








## **O que são metas de vida**

**Metas de vida** são objetivos **amplos, significativos e de longo prazo** que você deseja alcançar ao longo da sua existência. Elas dão **direção, propósito e motivação** às suas decisões e projetos.

> São como um "norte pessoal" — aquilo que, se você alcançar, vai sentir que sua vida valeu a pena.

---

## 🧠 Exemplos de metas de vida

| Área da vida        | Exemplo de Meta de Vida                                          |
| ------------------- | ---------------------------------------------------------------- |
| Profissional        | Ser especialista em ciência de dados e trabalhar remotamente     |
| Acadêmica           | Concluir uma pós-graduação e contribuir com pesquisa científica  |
| Financeira          | Alcançar independência financeira até os 40 anos                 |
| Pessoal/saúde       | Manter saúde e bem-estar com rotina ativa e alimentação saudável |
| Familiar/relacional | Construir uma família estável e presente                         |
| Espiritual/pessoal  | Viver com propósito e equilíbrio emocional                       |

---

## ✅ Como definir suas metas de vida

1. **Reflexão profunda**: Pense sobre o que realmente importa pra você.  
    Perguntas úteis:
    
    - O que eu mais valorizo?
        
    - Que legado quero deixar?
        
    - O que me motiva de verdade?
        
2. **Escreva no presente e com clareza**:
    
    - "Tenho liberdade financeira e trabalho com o que amo"
        
    - "Sou reconhecido como referência em minha área"
        
3. **Agrupe por áreas da vida**:  
    Crie seções como:
    
    - 💼 Profissional
        
    - 📚 Acadêmica
        
    - 💰 Financeira
        
    - ❤️ Pessoal
        
    - 🌱 Espiritual
        
4. **Revise periodicamente**:  
    Sua visão pode mudar com o tempo — e tudo bem. Use o Obsidian pra ajustar e evoluir.