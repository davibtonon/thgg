

[Site sobre Trance](https://trance.com.br/blog/festivais/universo-paralello-historia)
[Formas de amarra o cadaço.](https://www.fieggen.com/shoelace/lacingmethods.htm)
[Aparelho para fazer flexão.](https://up-forces.com/collections/frontpage/products/apoio-para-flexao-de-braco-force-up-prancha-dobravel?utm_medium=paid&utm_id=120206811493240402&utm_content=120207537277430402&utm_term=120207537277440402&utm_campaign=120206811493240402&fbclid=PAAaZGDNCWwhgnDaX_S8qAY-3YLKMgnNnlaGUK7xzziLZAlV-y2nKcH6FpwFc_aem_AZiPXIhxjMTdsyy28mh40ybb3CAPe-tSLnncTyONkrfrfbngAt8fUk3UPHcV9sOGcbOjdi1bkS8VmihlI3eZGv1m&utm_source=facebook&campaign_id=120207537277440402&ad_id=120207537277430402)
[Curso de Astrofísica UFSC](https://astrofisica.ufsc.br/aa/g/material/)
[Maneira correta de convesa por msg](https://nohello.net/pt-br/)
[Natureza Divina](https://www.naturezadivina.com.br/)
[zettelkasten](https://zettelkasten.de/introduction/)
[Gulbenkian](https://gulbenkian.pt/musica/)
[Curso](https://downloadcursos.gratis/)
[Biblioteca do condado](https://biblioteca-do-condado.mailchimpsites.com/)
[Streaming  - Reedit]([Guia do Streaming Doméstico Automatizado (Sonarr, Radarr e Plex) : r/pirataria](https://www.reddit.com/r/pirataria/comments/18ch7bt/guia_do_streaming_dom%C3%A9stico_automatizado_sonarr/))
[Livro Banco de Dados](https://db-book.com/)
## Site de roupas e acessórios.

[Estilo Sigman](https://www.estilosigman.com.br/)
[Universo Maschio](https://universomaschio.com.br/)
[Anarhu](https://www.anarhu.com.br/)
[Bluhen](https://www.bluhen.com.br/)
## Investimentos.

[KNSC11](https://www.kinea.com.br/fundos/fundo-imobiliario-kinea-securities-knsc11/)
[CPRT11](https://capitaniafiagro.com.br/cptr11/)


## Filmes
https://downloadcult.org/0463-a-bela-da-tarde-1967/
https://downloadcult.org/0601-salo-ou-os-120-dias-de-sodoma-1975/

## Periódicos  Cientificos

**IEEE Xplore**, **Springer** e **ScienceDirect**
https://archive.ics.uci.edu/

[Journal of Cloud Computing](https://journalofcloudcomputing.springeropen.com/)


https://www.reddit.com/r/BDSMOnlyFans_Pages/comments/1ckzoi7/best_bondage_and_bdsm_onlyfans_girls_full_list_of/?tl=pt-br

https://www.quantamagazine.org/quantum-scientists-have-built-a-new-math-of-cryptography-20250725/

https://www.newscientist.com/