[[Introdução aos bancos de dados]]
[[Introdução a Rede de ]]
Preciso de um site como um Bloq para minhas ideias. Quero fazer um... Tenho algumas ideias que somente depois não lembro de nenhuma delas. 13/09/24
Mestrado - Área de Tecnologia.
Prova Poscomp
[Para visitar - Stryn](https://pt.wikipedia.org/wiki/Stryn)

[Teclado mecanico](https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwjElZSamr6JAxXkAq0GHSSNO-kYABAcGgJwdg&ae=2&co=1&gclid=Cj0KCQjwm5e5BhCWARIsANwm06gcUk-iLT8iRAlL62Nm8RYDXp3P9EidAtbf2U_RgRVZpk0JvK4dOGsaAmJ4EALw_wcB&ohost=www.google.com&cid=CAESVeD2_XXsm0U98_v5C5cs67aKOYsC_S_Cz1GbrA0U1xwwhGvNmF7i0ZiXxrn2vypCgeii6LKqZ5HRKF2LOgHcairzdTYeoyLD4iAc93psssmI4_T7xFU&sig=AOD64_2qjOKiY0L5heBSka0mA1OZXmMwfg&ctype=5&q=&ved=2ahUKEwiHzImamr6JAxULLrkGHbEsIPMQ9aACKAB6BAgGECM&adurl=)



