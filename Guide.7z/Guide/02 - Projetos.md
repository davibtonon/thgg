
>Aqui será um local para ver tudo sobre minha vida. Ainda não tenho certeza de como vai funciona, nem sei se vou continua. A final todo fim de ano tento algo novo...


Aqui estão minhas [[00 - Especificações]]
- [ ] [[00_2025 |Modelo Base]]


## Andamentos
- [ ] 01_2025 - [[02 - Projetos/01_2025 |Analise e Desenvolvimento de Sistemas]]
- [ ] 02_2025 - [[02_2025 |Jiu-Jitsu - Faixa Preta]]
- [ ] 03_2025 - [[03_2025 |Português Descomplicado]] 
- [ ] 04_2025 - [[04_2025 |Novíssima Gramática da Língua Portuguesa ]]
- [ ] 05_2025 -  [[05_2025 |Caligrafia Tradicional Brasileira]]
- [ ] 06_2025 - [[06_2025 |Compass]]
- [ ] 07_2025 - [[07_2025 |Ask Jackie]]




- [ ] Curso de Inglês Ask Jackie. #ask_jackie
- [ ] [Fabio Akita - Que curso devo fazer ?]( https://www.youtube.com/playlist?list=PLdsnXVqbHDUd6wEL932R7dW9Zazt2oNWF)
- [ ] [[02 - Projetos/]] [[ Manual de Analise de Dados]] 
- [ ] [[Introdução a Estrutura de dados]]







Jiu-Jitsu - Faixa Preta